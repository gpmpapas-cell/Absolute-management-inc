# Morphe Management — Website

React + Vite + Tailwind one‑page site with MM logo.

## Local dev
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
npm run preview
```

## Deploy (Free)

### Vercel (recommended)
1) Push this folder to a new GitHub repo.
2) Go to https://vercel.com → New Project → Import the repo → Deploy.
3) Framework preset: **Vite**. Build: `npm run build`. Output: `dist`.

### Netlify
1) Connect Git to this repo OR run:
   ```bash
   npm run build
   ```
2) Drag the `/dist` folder into the Netlify dashboard.

### GitHub Pages
If you prefer GH Pages, install:
```bash
npm i -D gh-pages
```
Add to `package.json`:
```json
"homepage": "https://<your-username>.github.io/morphe-management-site",
"scripts": {
  "predeploy": "npm run build",
  "deploy": "gh-pages -d dist"
}
```
Then:
```bash
npm run deploy
```
