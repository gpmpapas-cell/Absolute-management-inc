import React, { useMemo } from "react";
import { motion } from "framer-motion";
import {
  Calculator,
  BarChart3,
  BookOpenCheck,
  TrendingUp,
  ShieldCheck,
  Clock3,
  Building2,
  CheckCircle2,
  Phone,
  Mail,
  MapPin,
  ArrowRight,
} from "lucide-react";

const CONTACT = {
  email: "info@AbsoluteManagementInc.com",
  phone: "+1 (416) 555‑0199",
  address: "Toronto, ON, Canada",
  booking: "https://calendly.com/absolute-mgmt/intro-call",
};

const nav = [
  { label: "Services", href: "#services" },
  { label: "Industries", href: "#industries" },
  { label: "Process", href: "#process" },
  { label: "Pricing", href: "#pricing" },
  { label: "About", href: "#about" },
  { label: "FAQ", href: "#faq" },
  { label: "Blog", href: "#blog" },
  { label: "Contact", href: "#contact" },
];

const fadeIn = {
  hidden: { opacity: 0, y: 16 },
  show: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

function LogoMark({ className = "h-10 w-10" }) {
  return (
    <svg className={className} viewBox="0 0 64 64" role="img" aria-label="Absolute Management Inc monogram">
      <defs>
        <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#1e1b4b" />
          <stop offset="100%" stopColor="#0f172a" />
        </linearGradient>
      </defs>
      <circle cx="32" cy="32" r="30" fill="url(#g)" stroke="#f59e0b" strokeWidth="2" />
      <text x="50%" y="54%" textAnchor="middle" fontFamily="ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto" fontSize="22" fontWeight="700" fill="#fde68a" letterSpacing="2">AMI</text>
    </svg>
  );
}

function LogoFull({ className = "h-8" }) {
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <LogoMark className="h-8 w-8" />
      <div className="leading-tight">
        <div className="text-sm font-semibold text-indigo-950">Absolute Management Inc</div>
        <div className="text-xs text-indigo-800">Financial • Managerial • Bookkeeping</div>
      </div>
    </div>
  );
}

function SectionTitle({ eyebrow, title, subtitle }) {
  return (
    <div className="mx-auto max-w-3xl text-center">
      {eyebrow && (
        <p className="mb-2 inline-block rounded-full bg-amber-100 px-3 py-1 text-xs font-medium tracking-wide text-indigo-950">
          {eyebrow}
        </p>
      )}
      <h2 className="text-2xl font-semibold tracking-tight text-indigo-950 sm:text-3xl">{title}</h2>
      {subtitle && <p className="mt-3 text-indigo-800">{subtitle}</p>}
    </div>
  );
}

function CTAButtons() {
  return (
    <div className="mt-6 flex flex-wrap items-center justify-center gap-3">
      <a href={CONTACT.booking} className="group inline-flex items-center gap-2 rounded-2xl bg-indigo-950 px-5 py-3 text-sm font-medium text-amber-100 shadow-lg transition hover:translate-y-[-1px] hover:shadow-xl">
        Book a free consultation
        <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
      </a>
      <a href={`mailto:${CONTACT.email}?subject=Question%20-%20Absolute%20Management%20Inc`} className="inline-flex items-center gap-2 rounded-2xl border border-amber-400 bg-white px-5 py-3 text-sm font-medium text-indigo-950 transition hover:border-amber-500">
        Ask a question
      </a>
    </div>
  );
}

function Stat({ value, label }) {
  return (
    <div className="rounded-2xl bg-amber-50/70 p-4 text-center shadow-sm ring-1 ring-amber-100">
      <div className="text-xl font-semibold text-indigo-950">{value}</div>
      <div className="mt-1 text-xs text-indigo-800">{label}</div>
    </div>
  );
}

function ServiceCard({ icon: Icon, title, points }) {
  return (
    <motion.div variants={fadeIn} className="h-full">
      <div className="flex h-full flex-col rounded-2xl border border-amber-100 bg-white p-6 shadow-sm">
        <div className="mb-4 flex items-center gap-3">
          <div className="grid h-10 w-10 place-items-center rounded-xl bg-indigo-950 text-amber-200">
            <Icon className="h-5 w-5" />
          </div>
          <h3 className="text-lg font-semibold text-indigo-950">{title}</h3>
        </div>
        <ul className="mt-2 space-y-2 text-sm text-indigo-900">
          {points.map((p, i) => (
            <li key={i} className="flex items-start gap-2">
              <CheckCircle2 className="mt-0.5 h-4 w-4 flex-none text-amber-500" />
              <span>{p}</span>
            </li>
          ))}
        </ul>
      </div>
    </motion.div>
  );
}

function PricingCard({ name, price, bullets, highlight }) {
  return (
    <div className={`flex h-full flex-col rounded-2xl border bg-white p-6 shadow-sm ${highlight ? "border-indigo-950 ring-2 ring-indigo-950" : "border-amber-100"}`}>
      <div className="flex items-baseline justify-between">
        <h3 className="text-lg font-semibold text-indigo-950">{name}</h3>
        <span className="text-sm text-indigo-700">from</span>
      </div>
      <div className="mt-1 text-3xl font-bold tracking-tight text-indigo-950">{price}</div>
      <ul className="mt-4 space-y-2 text-sm text-indigo-900">
        {bullets.map((b, i) => (
          <li key={i} className="flex items-start gap-2">
            <CheckCircle2 className="mt-0.5 h-4 w-4 text-amber-500" />
            <span>{b}</span>
          </li>
        ))}
      </ul>
      <a href={`mailto:${CONTACT.email}?subject=${encodeURIComponent(name + " Plan Inquiry - Absolute Management Inc")}`} className="mt-5 inline-flex items-center justify-center rounded-xl bg-indigo-950 px-4 py-2.5 text-sm font-medium text-amber-100 hover:opacity-95">
        Choose {name}
      </a>
    </div>
  );
}

function App() {
  const year = useMemo(() => new Date().getFullYear(), []);
  return (
    <div className="min-h-screen scroll-smooth bg-stone-50 text-indigo-950">
      <header className="sticky top-0 z-40 border-b border-amber-200 bg-white/80 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
          <a href="#top" className="flex items-center gap-3" aria-label="Absolute Management Inc home">
            <LogoFull />
          </a>
          <nav className="hidden items-center gap-6 md:flex">
            {nav.map((n) => (
              <a key={n.href} href={n.href} className="text-sm text-indigo-800 transition hover:text-indigo-950">{n.label}</a>
            ))}
            <a href={CONTACT.booking} className="rounded-xl bg-indigo-950 px-4 py-2 text-sm font-medium text-amber-100 hover:opacity-95">Free Consultation</a>
          </nav>
        </div>
      </header>

      <section id="top" className="relative overflow-hidden">
        <div className="pointer-events-none absolute inset-0 -z-10 bg-[radial-gradient(60rem_60rem_at_50%_-10%,rgba(15,23,42,0.08),transparent)]" />
        <div className="mx-auto max-w-7xl px-4 py-20 sm:py-28">
          <motion.div initial="hidden" animate="show" variants={fadeIn}>
            <p className="inline-block rounded-full bg-amber-100 px-3 py-1 text-xs font-medium tracking-wide text-indigo-950 ring-1 ring-amber-200">Absolute Management Inc</p>
            <h1 className="mt-4 text-3xl font-semibold leading-tight sm:text-5xl">Financial, managerial & bookkeeping services<span className="block text-indigo-800">built for growing businesses.</span></h1>
            <p className="mt-4 max-w-2xl text-indigo-800">We help owners focus on growth while we handle the numbers: clean books, clear reporting, and steady guidance.</p>
            <CTAButtons />
            <div className="mt-10 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <Stat value="End‑to‑end support" label="From setup to monthly close" />
              <Stat value="Transparent fees" label="Simple, flexible engagement" />
              <Stat value="Secure workflows" label="Best‑practice controls" />
              <Stat value="Hands‑on guidance" label="Partner‑style communication" />
            </div>
          </motion.div>
        </div>
      </section>

      <section id="services" className="mx-auto max-w-7xl px-4 py-16 sm:py-20">
        <SectionTitle eyebrow="What we do" title="Clarity, compliance, and control" subtitle="Pick a single service or bundle them for an end‑to‑end finance function." />
        <motion.div initial="hidden" whileInView="show" viewport={{ once: true, amount: 0.2 }} className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          <ServiceCard icon={Calculator} title="Bookkeeping & Compliance" points={["Monthly/quarterly bookkeeping and reconciliations","AR/AP management and bill pay workflows","Sales tax (HST/VAT) tracking and filings","Year‑end handoff packages for your CPA"]} />
          <ServiceCard icon={BarChart3} title="Financial Reporting" points={["Monthly close and management reports","Cash‑flow tracking and 13‑week forecasts","KPI dashboards tailored to your business","Budget vs actuals and variance analysis"]} />
          <ServiceCard icon={BookOpenCheck} title="Managerial Advisory" points={["Costing, pricing, and margin optimization","Process design and internal controls","Systems setup: cloud accounting & apps","Board‑ready packs and investor updates"]} />
        </motion.div>
        <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-3">
          {[{ Icon: ShieldCheck, label: "Professional standards & confidentiality" },{ Icon: Clock3, label: "On‑time monthly closes" },{ Icon: TrendingUp, label: "Insight that drives decisions" },].map(({ Icon, label }, i) => (
            <div key={i} className="flex items-center gap-3 rounded-2xl border border-amber-100 bg-white p-4 shadow-sm">
              <Icon className="h-5 w-5" />
              <span className="text-sm text-indigo-900">{label}</span>
            </div>
          ))}
        </div>
      </section>

      <section id="industries" className="border-y border-amber-100 bg-white/60">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:py-20">
          <SectionTitle eyebrow="Who we serve" title="Tailored for your sector" subtitle="Our methods adapt to the realities of your industry." />
          <div className="mt-10 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {[{ title: "Real Estate & Property", desc: "Rental, development, and prop‑tech" },{ title: "Hospitality & F&B", desc: "Restaurants, cafés, and venues" },{ title: "E‑commerce & Retail", desc: "Omni‑channel inventory and POS" },{ title: "Professional Services", desc: "Agencies, studios, and consultants" },].map(({ title, desc }, i) => (
              <div key={i} className="rounded-2xl border border-amber-100 bg-white p-5 shadow-sm">
                <div className="mb-2 flex items-center gap-2 text-sm font-medium text-indigo-950"><Building2 className="h-4 w-4" /> {title}</div>
                <p className="text-sm text-indigo-800">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="process" className="mx-auto max-w-7xl px-4 py-16 sm:py-20">
        <SectionTitle eyebrow="How it works" title="A simple, reliable engagement" subtitle="Clear steps, predictable cadence, and measurable outcomes." />
        <ol className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {[{ step: "1", title: "Discover", text: "30‑min intro to understand goals and scope." },{ step: "2", title: "Setup", text: "System audit, chart‑of‑accounts, and workflows." },{ step: "3", title: "Deliver", text: "Monthly close, reports, and action items." },{ step: "4", title: "Support", text: "Quarterly reviews and ongoing advisory." },].map(({ step, title, text }) => (
            <li key={step} className="rounded-2xl border border-amber-100 bg-white p-6 shadow-sm">
              <div className="mb-3 inline-flex h-8 w-8 items-center justify-center rounded-full bg-indigo-950 text-sm font-semibold text-amber-100">{step}</div>
              <div className="font-semibold text-indigo-950">{title}</div>
              <p className="mt-1 text-sm text-indigo-800">{text}</p>
            </li>
          ))}
        </ol>
      </section>

      <section id="pricing" className="border-y border-amber-100 bg-white/60">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:py-20">
          <SectionTitle eyebrow="Flexible options" title="Packages that fit your stage" subtitle="Indicative pricing. We’ll tailor scope and tools to your needs." />
          <div className="mt-10 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
            <PricingCard name="Starter" price="$399/mo" bullets={["Monthly bookkeeping (up to 100 txns)", "Basic financial statements", "HST/VAT tracking", "Email support"]} />
            <PricingCard name="Growth" price="$799/mo" bullets={["Full monthly close + reconciliations", "Management report pack", "Cash‑flow & KPI dashboard", "Priority support & quarterly review"]} highlight />
            <PricingCard name="Complete" price="$1,399/mo" bullets={["Dedicated account lead", "AP/AR workflows & bill pay", "Budgeting & forecasting", "Board‑ready reporting"]} />
          </div>
        </div>
      </section>

      <section id="about" className="mx-auto max-w-7xl px-4 py-16 sm:py-20">
        <div className="grid items-center gap-10 lg:grid-cols-2">
          <div>
            <SectionTitle eyebrow="About us" title="Your embedded finance partner" subtitle="We combine rigorous bookkeeping with management insight so owners can make confident, timely decisions." />
            <ul className="mt-6 space-y-3 text-sm text-indigo-900">
              {["Cloud‑first, secure, and paper‑light workflows", "Tool‑agnostic: we work with QuickBooks, Xero, and leading apps", "No long contracts — scale up or down as needs change"].map((t, i) => (
                <li key={i} className="flex items-start gap-2">
                  <CheckCircle2 className="mt-0.5 h-4 w-4 text-amber-500" /> {t}
                </li>
              ))}
            </ul>
            <CTAButtons />
          </div>
          <div className="rounded-3xl border border-amber-100 bg-white p-6 shadow-sm">
            <div className="flex items-center gap-3">
              <LogoMark className="h-10 w-10" />
              <div>
                <div className="text-sm font-semibold text-indigo-950">Absolute Management Inc</div>
                <div className="text-xs text-indigo-800">Trusted by growing businesses</div>
              </div>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
              <div className="rounded-xl bg-stone-50 p-4">
                <div className="font-medium text-indigo-950">Core Values</div>
                <p className="mt-1 text-indigo-800">Integrity, clarity, reliability.</p>
              </div>
              <div className="rounded-xl bg-stone-50 p-4">
                <div className="font-medium text-indigo-950">Approach</div>
                <p className="mt-1 text-indigo-800">Hands‑on collaboration and practical insight.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section id="faq" className="border-y border-amber-100 bg-white/60">
        <div className="mx-auto max-w-7xl px-4 py-16 sm:py-20">
          <SectionTitle eyebrow="FAQ" title="Answers to common questions" />
          <div className="mt-8 grid grid-cols-1 gap-4 md:grid-cols-2">
            {[
              { q: "Can you work with our existing accountant?", a: "Yes. We collaborate seamlessly with your external CPA for tax and year‑end, while we operate your month‑to‑month finance function." },
              { q: "Do you replace an internal bookkeeper?", a: "Often we augment or fully replace bookkeeping with a broader reporting and advisory layer, depending on your needs." },
              { q: "What does onboarding look like?", a: "A short discovery, secure document intake, systems setup, and a targeted first monthly close within 30 days for most SMEs." },
              { q: "What tools do you support?", a: "QuickBooks Online, Xero, Dext, Plooto/Bill, Stripe, POS systems, and more — we’re tool‑agnostic." },
            ].map(({ q, a }, i) => (
              <div key={i} className="rounded-2xl border border-amber-100 bg-white p-5 shadow-sm">
                <div className="font-medium text-indigo-950">{q}</div>
                <p className="mt-2 text-sm text-indigo-800">{a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="blog" className="mx-auto max-w-7xl px-4 py-16 sm:py-20">
        <SectionTitle eyebrow="Insights" title="From the AMI blog" subtitle="Short, actionable reads on finance and operations." />
        <div className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-3">
          {[1, 2, 3].map((i) => (
            <article key={i} className="rounded-2xl border border-amber-100 bg-white p-5 shadow-sm">
              <h3 className="text-base font-semibold text-indigo-950">Sample Post Title {i}</h3>
              <p className="mt-2 text-sm text-indigo-800">A 2–3 sentence summary that teases the lesson and invites a click.</p>
              <a href="#" className="mt-3 inline-block text-sm font-medium text-indigo-950 underline decoration-amber-400 underline-offset-4 hover:opacity-90">Read more</a>
            </article>
          ))}
        </div>
      </section>

      <section id="contact" className="mx-auto max-w-7xl px-4 py-16 sm:py-20">
        <div className="grid items-start gap-8 lg:grid-cols-3">
          <div className="rounded-2xl border border-amber-100 bg-white p-6 shadow-sm">
            <SectionTitle eyebrow="Get in touch" title="Let’s make the numbers work for you" subtitle="Drop us a note — we’ll reply within one business day." />
            <div className="mt-5 space-y-3 text-sm text-indigo-900">
              <div className="flex items-center gap-2"><Mail className="h-4 w-4" /><a className="hover:underline" href={`mailto:${CONTACT.email}`}>{CONTACT.email}</a></div>
              <div className="flex items-center gap-2"><Phone className="h-4 w-4" /><a className="hover:underline" href={`tel:${CONTACT.phone}`}>{CONTACT.phone}</a></div>
              <div className="flex items-center gap-2"><MapPin className="h-4 w-4" />{CONTACT.address}</div>
            </div>
          </div>

          <form onSubmit={(e) => {
              e.preventDefault();
              const fd = new FormData(e.currentTarget);
              const name = fd.get("name");
              const email = fd.get("email");
              const company = fd.get("company");
              const msg = fd.get("message");
              const subject = encodeURIComponent(`Inquiry from ${name} (${company || "No company"})`);
              const body = encodeURIComponent(`Name: ${name}\nEmail: ${email}\nCompany: ${company}\n\nMessage:\n${msg}`);
              window.location.href = `mailto:${CONTACT.email}?subject=${subject}&body=${body}`;
            }}
            className="lg:col-span-2">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="text-sm font-medium">Name</label>
                <input name="name" required className="mt-1 w-full rounded-xl border border-amber-300 bg-white px-3 py-2 text-sm outline-none ring-0 placeholder:text-indigo-300 focus:border-indigo-950" placeholder="Your full name" />
              </div>
              <div>
                <label className="text-sm font-medium">Email</label>
                <input type="email" name="email" required className="mt-1 w-full rounded-xl border border-amber-300 bg-white px-3 py-2 text-sm outline-none focus:border-indigo-950" placeholder="you@company.com" />
              </div>
              <div>
                <label className="text-sm font-medium">Company</label>
                <input name="company" className="mt-1 w-full rounded-xl border border-amber-300 bg-white px-3 py-2 text-sm outline-none focus:border-indigo-950" placeholder="Optional" />
              </div>
              <div>
                <label className="text-sm font-medium">Phone</label>
                <input name="phone" className="mt-1 w-full rounded-xl border border-amber-300 bg-white px-3 py-2 text-sm outline-none focus:border-indigo-950" placeholder="Optional" />
              </div>
            </div>
            <div className="mt-4">
              <label className="text-sm font-medium">How can we help?</label>
              <textarea name="message" rows={5} required className="mt-1 w-full rounded-xl border border-amber-300 bg-white px-3 py-2 text-sm outline-none focus:border-indigo-950" placeholder="Tell us about your needs or challenges…" />
            </div>
            <div className="mt-4 flex flex-wrap gap-3">
              <button type="submit" className="inline-flex items-center gap-2 rounded-xl bg-indigo-950 px-5 py-3 text-sm font-medium text-amber-100 hover:opacity-95">
                Send message <ArrowRight className="h-4 w-4" />
              </button>
              <a href={CONTACT.booking} className="inline-flex items-center gap-2 rounded-xl border border-amber-400 px-5 py-3 text-sm font-medium text-indigo-950 hover:border-amber-500">
                Book a call
              </a>
            </div>
          </form>
        </div>
      </section>

      <footer className="border-t border-amber-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 py-8">
          <div className="flex flex-col items-center justify-between gap-4 sm:flex-row">
            <LogoFull />
            <div className="flex items-center gap-4 text-sm">
              <a href="#top" className="text-indigo-800 hover:text-indigo-950">Back to top</a>
              <span className="text-amber-400">•</span>
              <a href="#" className="text-indigo-800 hover:text-indigo-950">Privacy</a>
              <a href="#" className="text-indigo-800 hover:text-indigo-950">Terms</a>
              <span className="text-indigo-800">© {year} Absolute Management Inc</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
